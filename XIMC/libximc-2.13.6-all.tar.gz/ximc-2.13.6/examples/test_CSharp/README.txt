Eng.

How to work with example.

1. Wrapper assembly for libximc.dll is ximc/win**/wrappers/csharp/ximcnet.dll. It is provided with two different architectures.
2. Supports the platform .NET from 2.0. to 4.0.
3. You can use Visual Studio 2013 to build and run the example.
4. The library with dependencies is located in the ximc/win * * folders. For the example to work, you need the following files: bindy.dll, libximc.dll, xiwrapper.dll, keyfile.sqlite.
5. To run the compiled example, you need to copy all the dependencies specified in step 1 and 4 to the folder with the executable file.


Rus.

Как работать с примером.
 
1. Для использования библиотеки libximc.dll в среде .NET предлагается обертка ximc/win**/wrappers/csharp/ximcnet.dll 
для операционной системы разной разрядности.
2. Поддерживаются платформы .NET от 2.0 до 4.0.
3. Для сборки и запуска примера можно использовать среду Visual Studio 2013.
4. Библиотека с зависимостями расположена в папках ximc/win**. Для работы примера необходимы файлы: bindy.dll, libximc.dll, xiwrapper.dll, keyfile.sqlite.
5. Для запуска скомпилированного примера необходимо все зависимости указанные в пунктах 1 и 4 скопировать в папку с выполняемым файлом.
