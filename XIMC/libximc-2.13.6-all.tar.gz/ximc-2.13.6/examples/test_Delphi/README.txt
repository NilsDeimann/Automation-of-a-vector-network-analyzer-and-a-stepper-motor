Eng. To work this example copy files ximc.pas, keyfile.sqlite, libximc.dll, xiwrapper.dll, bindy.dll from ximc folder next to test_Delphi.dpr
and run test_Delphi.dpr with you'r Delphi IDE.
To run compiled example without ide (through the command line), run test_Delphi.exe

Ru. Для работы примера скопируйте файлы ximc.pas, keyfile.sqlite, libximc.dll, xiwrapper.dll, bindy.dll из папки ximc рядом с test_Delphi.dpr
и запустите test_Delphi.dpr с помощью Вашей Delphi IDE
Чтобы запустить скомпилированный пример из командной строки, запустите test_Delphi.exe