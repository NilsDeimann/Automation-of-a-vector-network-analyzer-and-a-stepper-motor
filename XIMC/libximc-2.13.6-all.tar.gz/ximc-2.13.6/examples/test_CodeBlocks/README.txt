Eng.

How to work with example.

1. Before starting:
* On OS X: copy ximc/macosx/libximc.framework, ximc/ximc.h to the directory
examples/test_CodeBlocks. Install XCode compatible with CodeBlocks.
* For Linux: Install libximc*deb and libximc-dev*dev of the target architecture. Then copy ximc/ximc.h to the directory
examples/test_CodeBlocks. Install gcc compatible with CodeBlocks.
* In Windows, you must use MS Visual C++ to compile. Make sure that the Microsoft Visual C++ Redistributable Package is installed.
The library with dependencies is located in the ximc/win** folders. The following files are required for the example to work: bindy.dll, libximc.dll, xiwrapper.dll
2. To build and run, open the examples/test_CodeBlocks/test_CodeBlocks.cbp project in CodeBlocks. Build and run the application from the development environment.

For modify:
The example code can be modified in the CodeBlocks editor.


Rus.

Как работать с примером

1. Перед запуском:
* На OS X: скопируйте ximc/macosx/libximc.framework, ximc/ximc.h в каталог
examples/test_CodeBlocks. Установите XCode, совместимый с CodeBlocks.
* Для Linux: установите libximc*deb и libximc-dev*dev целевой архитектуры. Затем скопируйте ximc/ximc.h в каталог
examples/test_CodeBlocks. Установите gcc, совместимый с CodeBlocks.
* В Windows для компиляции необходимо использовать MS Visual C++. Убедитесь, что Microsoft Visual C++ Redistributable Package установлен. 
Библиотека с зависимостями находится в папках ximc/win**. Для работы примера неоходимы следующие файлы: bindy.dll, libximc.dll, xiwrapper.dll.
2. Для сборки и запуска откройте проект examples/test_CodeBlocks/test_CodeBlocks.cbp в CodeBlocks. Выполните сборку и запустите приложение из среды разработки.

 
Для модификации примера:
Код примера можно модифицировать в редакторе CodeBlocks.